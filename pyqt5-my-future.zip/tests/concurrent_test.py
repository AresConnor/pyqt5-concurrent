import functools
import os
import random
import sys
import time
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from PyQt5.QtCore import QThread, QTimer
from PyQt5.QtWidgets import QApplication

from src.concurrent_.taskManager import TaskExecutor

app = QApplication(sys.argv)

# ===============================================================================
print("测试函数传参\n" + "=" * 50)


def func(i: int, *args, **kwargs) -> int:
    r = random.randint(1, 5)
    print("task <{}> sleep {}s,current Thread:{}".format(i, r, QThread.currentThread()))
    time.sleep(r)
    print("task <{}> done".format(i))
    return r


func_ptr = functools.partial(func)

# partial test (没必要)
executor = TaskExecutor(useGlobalThreadPool=False)
for i in range(10):
    executor.asyncRun(func_ptr, i)
executor.threadPool.waitForDone()
executor.deleteLater()
print("测试完成\n" + "=" * 50)
# ===============================================================================


# ===============================================================================
print("测试partial包装的函数\n" + "=" * 50)
# partial wrapped lambda test (多此一举)
executor = TaskExecutor(useGlobalThreadPool=False)
for i in range(10):
    executor.asyncRun(
        functools.partial(
            lambda i, *args, **kwargs: {
                (r := random.randint(1, 5)),
                print("task <{}> sleep {}s,current Thread:{}".format(i, r, QThread.currentThread())),
                time.sleep(r),
                print("task <{}> done".format(i)),
                r
            }),
        i)

executor.threadPool.waitForDone()
executor.deleteLater()
print("测试完成\n" + "=" * 50)
# ===============================================================================

# ===============================================================================
print("测试lambda匿名函数\n" + "=" * 50)
# lambda test (直接用lambda就行,因为manager.asyncRun()会自动包装成functools.partial)
executor = TaskExecutor(useGlobalThreadPool=False)
for i in range(10):
    executor.asyncRun(lambda i: {
        (r := random.randint(1, 5)),
        print("task <{}> sleep {}s,current Thread:{}".format(i, r, QThread.currentThread())),
        time.sleep(r),
        print("task <{}> done".format(i)),
        r
    }, i)

executor.threadPool.waitForDone()
executor.deleteLater()
print("测试完成\n" + "=" * 50)


# ===============================================================================

def savePage(html, path):
    with open(path, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f"saved page to path: {path}")


def getPage(url):
    import requests
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36 Edg/118.0.0.0"
    response = requests.request(
        method='GET',
        url=url,
        headers={'User-Agent': ua}
    )
    return response.text

print("测试异步爬虫\n" + "=" * 50)
run = TaskExecutor.getGlobalInstance().asyncRun(getPage, "https://www.baidu.com")
run.result.connect(lambda r: savePage(r, "baidu.html"))
run.done.connect(lambda _: QTimer.singleShot(1000, app.quit))
sys.exit(app.exec_())
